<footer class="footer footer-alt">
            2020 - <?php echo date ('Y');?> &copy; Hospital Managememt Information System. Proudly Powered  By <a href="https://martmbithi.github.io" target = "_blank" class="text-white-50">MartDevelopers Inc</a> 
</footer>