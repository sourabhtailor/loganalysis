<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="martdevelopers_his";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>
