<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2020 - <?php echo date('Y'); ?> &copy; Hospital Managememt Information System. Proudly Powered By <a href="https://martmbithi.github.io" target="_blank">MartDevelopers Inc</a>
            </div>

        </div>
    </div>
</footer>