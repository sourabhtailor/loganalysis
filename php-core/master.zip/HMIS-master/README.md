<p align="center"><img src="https://github.com/MartMbithi/HMIS/blob/master/backend/admin/assets/images/logo-dark.png"></p>
<hr>
<b>Hospital-Management-Information-System</b><br>
Hospital Management Information System Is More Advanced Hospital Information System  Build On <a href="https://github.com/MartMbithi/OHCMS">Orion HealthCare Hospital Management System</a>
<hr>
<li><b><u>It implements the following functionalities</u></b></li>
<hr>
<li>InPatient/OutPatient Management</li>
<li>Pharmacy Management</li>
<li>Accounting /Revenue Management</li>
<li>Advanced Reporting</li>
<li>Medical Records Management</li>
<li>Laboratory Management</li>
<li>Surgical/Theatre Management</li>
<li>Hospital Employee Management</li>
<li>Payroll Processing</li>
<li>Vendor Management</li>
<li>And Many More</li>
<hr>
Login Credentials<br>
Admin Module Email: sysadmin@his.org<br>
Admin Module Password: demo <br>
<hr>
  <b>Screenshots</b>
  <p align="center"><img src="https://github.com/MartMbithi/HMIS/blob/master/screenshots/1.png"></p>
  <p align="center"><img src="https://github.com/MartMbithi/HMIS/blob/master/screenshots/2.png"></p>

  
