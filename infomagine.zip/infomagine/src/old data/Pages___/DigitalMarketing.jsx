import React from 'react'

const DigitalMarketing = () => {
  return (
    <div>DigitalMarketing</div>
  )
}

export default DigitalMarketing